[Data.xlsx](https://github.com/user-attachments/files/23283724/Data.xlsx)
